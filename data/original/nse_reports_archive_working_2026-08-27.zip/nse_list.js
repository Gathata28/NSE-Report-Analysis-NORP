jQuery(document).ready(function($) {
    // This is required for AJAX to work on our page
    var ajaxurl = wp_ajax.ajaxurl;
    function load_all_posts(page,tags,chalid){
      var data = {
        page: page,
        action: 'list_dwnlds',
        security: wp_ajax.ajaxnonce,
        nse_id: chalid ? chalid : wp_ajax.nse_id,
        limit: wp_ajax.limit,
        tags:tags,
        expiry: wp_ajax.expiry,
        
      };
      // Send the data
      $.post(ajaxurl, data, function(response) {
        $("#nse_content"+chalid).html(response);
        $(".nse_content .filter_content_nse").empty();
      });
    }
    var ccnewchalid = $('.nse_content').attr('data-cid');
    load_all_posts('1', 'All', ccnewchalid);
    $(document).on('click','.nse_paginations div.active',function(){
      var page = $(this).attr('id');
      var tags = $('.nse_content').attr('data-year');
      var chalid = $('.nse_content').attr('data-cid');
      var newchalid = $(this).parents('.nse_content').attr('data-cid');
      load_all_posts(page,tags,newchalid);
    });
  

    // SEARCH FILTER

      function formfilter(filter){
        var data = {
          filter: filter,
          action: 'list_dwnlds',
          security: wp_ajax.ajaxnonce,
          nse_id: wp_ajax.nse_id
        };
        // Send the data
      $.post(ajaxurl, data, function(response) {
        $(".nse_content").html(response);
        
        $(".nse_content .filter_content_nse").empty();
      });
      }
      $(document).on('submit','#nse_filterform',function(){
      var filter = $('#nsfilterid').val();
      formfilter(filter);
      return false;
    });

    // TAGS FILTER

    function tagsfilters(tags,chalid){
      var data = {
        tags: tags,
        action: 'list_dwnlds',
        security: wp_ajax.ajaxnonce,
        nse_id: chalid,
      };
      // Send the data
    $.post(ajaxurl, data, function(response) {
      $("#nse_content"+chalid).html(response);
      $("#nse_content"+chalid+" .filter_content_nse").empty();
    });
    }
    $(document).on('click','.yearclick',function(){
      $('.yearclick').removeClass('active-filter');
      var tags = $(this).attr('data-year');
      var chalid = $(this).attr('data-cid');
      $(this).addClass('active-filter');
      tagsfilters(tags,chalid);
      $('.nse_content').attr('data-year', $(this).attr('data-year'))
      return false;
    });

  }); 
  