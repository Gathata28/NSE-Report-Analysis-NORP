from pathlib import Path
import subprocess
ROOT=Path('/home/ubuntu/nse_reports')
for pdf in sorted((ROOT/'kenya_orchards').glob('*.pdf')):
    outdir=pdf.parent/(pdf.stem+'_ocr')
    outdir.mkdir(exist_ok=True)
    subprocess.run(['pdftoppm','-jpeg','-r','150',str(pdf),str(outdir/'page')],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    pages=[]
    for image in sorted(outdir.glob('page-*.jpg')):
        txt=image.with_suffix('.txt')
        subprocess.run(['tesseract',str(image),str(txt.with_suffix('')), '-l','eng'],check=False,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        pages.append(txt.read_text(errors='replace') if txt.exists() else '')
    pdf.with_suffix('.ocr.txt').write_text('\f'.join(pages),encoding='utf-8')
    print(pdf.name, 'pages=',len(pages),'chars=',sum(map(len,pages)))
